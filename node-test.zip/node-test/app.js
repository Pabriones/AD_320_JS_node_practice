var add = (x,y) => {
    return x + y;
}

module.export = add;